package com.cg.dao;

public interface MACDAO {

}
