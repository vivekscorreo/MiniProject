package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;

public class ApplicationDAOImpl implements ApplicationDAO{
	
	Connection con;

	public ApplicationDAOImpl() {
		con= DBUtil.getConnection();
	}

	@Override
	public List<ProgramScheduled> getAllScheduledPrograms() {
		// TODO Auto-generated method stub
		
		List<ProgramScheduled> programScheduledList = new ArrayList<>();
		PreparedStatement pstmt = null;
		
        System.out.println("yaaaaaaaaaaaaaaaaaaaaaaaaaaaayyyyyyyyyyyyyyyyy");
		
		String qry ="SELECT * FROM Programs_Scheduled;";

		     try {
				pstmt = con.prepareStatement(qry);
				ResultSet resultSet = pstmt.executeQuery();
				while(resultSet.next()){
					ProgramScheduled programScheduled = new ProgramScheduled();
					programScheduled.setScheduledProgramId(resultSet.getString("scheduledProgramId"));
					programScheduled.setProgramName(resultSet.getString("programName"));
					programScheduled.setLocation(resultSet.getString("location"));
					programScheduled.setStartDate(resultSet.getDate("startDate"));
					programScheduled.setEndDate(resultSet.getDate("endDate"));
					programScheduled.setSessionsPerWeek(resultSet.getInt("sessionsPerWeek"));	
					programScheduledList.add(programScheduled);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		return programScheduledList;
	}

}
