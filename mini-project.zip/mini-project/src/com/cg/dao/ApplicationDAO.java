package com.cg.dao;

import java.util.List;
import com.cg.dto.ProgramScheduled;


public interface ApplicationDAO {

	List <ProgramScheduled> getAllScheduledPrograms();
}
