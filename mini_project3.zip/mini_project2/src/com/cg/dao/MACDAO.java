package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface MACDAO {

	public List <ProgramScheduled> getAllScheduledPrograms();
	public String updateStatus(String status,int id);
	public String setInterviewDate(LocalDate date,int id);
	public List<Application> showApplicationByStatus(String status);
}
