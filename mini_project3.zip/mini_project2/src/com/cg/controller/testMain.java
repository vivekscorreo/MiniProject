package com.cg.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.dao.ApplicationDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;


public class testMain {

	static Scanner ss1 = new Scanner(System.in);
	static Scanner ss2 = new Scanner(System.in);
	
	public static void main(String[] args){
		// TODO Auto-generated method stub
//test1:get schduled programs:working
		ApplicationDAOImpl appObj = new ApplicationDAOImpl();
		System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
		getAll();
		
//test2:status of application by id:working
	     Scanner ss = new Scanner(System.in);
	     System.out.println("Enter id");
    	 int id = ss.nextInt();
	     System.out.println(appObj.applicationStatus(id));
	     
//test3:insertion:WORKING
	     insert();
	}
	
	private static void insert() {
		ApplicationDAOImpl appObj = new ApplicationDAOImpl();
		// TODO Auto-generated method stub
		 Scanner ss = new Scanner(System.in);
		 
		 System.out.println("fn");
		 String fn = ss.next();
		 
		 LocalDate dob = LocalDate.now();

		 System.out.println("qulai");
		 String q = ss1.next();
		 
		 System.out.println("marks");
		 int marks = ss1.nextInt();
		 
		 System.out.println("goals");
		 String goals = ss1.next();
		 
		 System.out.println("email");
		 String email = ss2.next();
		 
		 System.out.println("sId");
		 String sid = ss2.next();
		
		 LocalDate doi = LocalDate.now();
		 
		 Application a = new Application(fn,dob,q,marks,goals,email,sid,doi);
		 int addData= appObj.addApplication(a);
		
	}

	private static void getAll() {
		ApplicationDAOImpl appObj = new ApplicationDAOImpl();
		// TODO Auto-generated method stub
		 ArrayList<ProgramScheduled> l1 = new ArrayList<ProgramScheduled>();
		 l1 = appObj.getAllScheduledPrograms();
		 
		 for(ProgramScheduled x: l1)
				System.out.println(x);
	}

}
