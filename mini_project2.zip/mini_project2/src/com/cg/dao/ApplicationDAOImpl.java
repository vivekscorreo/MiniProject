package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;

public class ApplicationDAOImpl implements ApplicationDAO{
	
	Connection con=null;

	public ApplicationDAOImpl() {
		
	}

	@Override
	public int addApplication(Application applicant) {
		int applicationId = 0;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		PreparedStatement appIdStatement = null;
		
		String qry ="INSERT INTO Application VALUES(applicationId_seq.NEXTVAL,?,?,?,?,?,?,?,'APPLIED',NULL)";
		//and to get application id from table which is automatically generated we use following query 
		String qry2 ="SELECT applicationId_seq.CURRVAL FROM DUAL";
		
		if (applicant != null) {
			
			try {
				con= DBUtil.getCon();
				pstmt = con.prepareStatement(qry);
				pstmt.setString(1, applicant.getFullName());
				pstmt.setDate(2, applicant.getDateOfBirth());
				pstmt.setString(3, applicant.getHighestQualification());
				pstmt.setInt(4, applicant.getMarksObtained());
				pstmt.setString(5, applicant.getGoals());
				pstmt.setString(6, applicant.getEmailId());
				pstmt.setString(7, applicant.getScheduledProgramId());
				int count = pstmt.executeUpdate();
				//System.out.println("Count is:" +count);
				if (count > 0){
					appIdStatement = con.prepareStatement(qry2);
					rs=appIdStatement.executeQuery();
					if(rs.next())
					{
						applicationId=rs.getInt(1);
					}
				}
				else {
				
					System.out.println("Inserting applicant details failed ");
				}
				
			}
			catch (SQLException | IOException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			}
		
		return applicationId;
	}
	
	@Override
	public List<ProgramScheduled> getAllScheduledPrograms() {
		// TODO Auto-generated method stub
		
		List<ProgramScheduled> programScheduledList = new ArrayList<>();
		PreparedStatement pstmt = null;
		
        String qry ="SELECT * FROM Programs_Scheduled";

		     try {
		    	con= DBUtil.getCon();
				pstmt = con.prepareStatement(qry);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()){
					System.out.println(rs.getString(0)+"\t\t\t\t"+rs.getString(1)+"\t\t\t\t"+rs.getString(2)+"\t\t\t\t"+rs.getDate(3)+"\t\t\t\t"+rs.getDate(4)+"\t\t\t\t"+rs.getInt(5));
					//vv
				}
			} 
		     catch (SQLException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		return programScheduledList;
	}


	@Override
	public String applicationStatus(int ID) {
		
		String status = null;
		PreparedStatement pstmt = null;
		String qry ="SELECT status FROM Application WHERE application_id=?";
				
		try {
			con= DBUtil.getCon();
			pstmt = con.prepareStatement(qry);
			pstmt.setInt(1,ID);
			ResultSet resultset = pstmt.executeQuery();
			if(resultset.next())
			{
				status = resultset.getString(1);			
			}
			
			
		} 
		catch (SQLException | IOException sqlException) {
			sqlException.printStackTrace();
		} 		
		return status;
	}

}




//ProgramScheduled programScheduled = new ProgramScheduled();
//programScheduled.setScheduledProgramId(resultSet.getString("scheduledProgramId"));
//programScheduled.setProgramName(resultSet.getString("programName"));
//programScheduled.setLocation(resultSet.getString("location"));
//programScheduled.setStartDate(resultSet.getDate("startDate"));
//programScheduled.setEndDate(resultSet.getDate("endDate"));
//programScheduled.setSessionsPerWeek(resultSet.getInt("sessionsPerWeek"));	
//programScheduledList.add(programScheduled);