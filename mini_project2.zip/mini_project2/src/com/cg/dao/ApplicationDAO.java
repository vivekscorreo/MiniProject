package com.cg.dao;

import java.util.List;

import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;


public interface ApplicationDAO {
	
	int addApplication(Application applicant);
	String applicationStatus(int ID);
	List <ProgramScheduled> getAllScheduledPrograms();
}
