package com.cg.service;

import java.util.List;

import com.cg.dao.ApplicationDAOImpl;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public class ApplicantServiceImpl implements ApplicantService{
	
	ApplicationDAOImpl dao=new ApplicationDAOImpl();

	@Override
	public List<ProgramScheduled> getAllScheduledPrograms() {
		// TODO Auto-generated method stub
		return dao.getAllScheduledPrograms();
	}

	@Override
	public int addApplication(Application applicant) {
		// TODO Auto-generated method stub
		return dao.addApplication(applicant);
	}

	@Override
	public String applicationStatus(int ID) {
		// TODO Auto-generated method stub
		return dao.applicationStatus(ID);
	}

}
